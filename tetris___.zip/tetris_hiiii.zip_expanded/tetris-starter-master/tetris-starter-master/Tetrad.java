import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Represents a Tetris piece.
public class Tetrad
{
	private static Random rand = new Random();
	private Block[] blocks;	// The blocks for the piece.
	private Color color;

	// Constructs a Tetrad.
	public Tetrad(BoundedGrid<Block> grid)
	{
		blocks = new Block[4];
		int rnd = rand.nextInt(7);
		Color col = Color.RED;
		Location[] loc = new Location[4]; 
		if (rnd == 0) {			
			for (int i = 0; i < 4; i ++) {
				loc[i] = new Location (0, i + 3);
			}
		} else if (rnd == 1) {
			col = Color.GRAY;
			loc[1] = new Location(0, 3);
			loc[0] = new Location(0, 4);
			loc[2] = new Location(0, 5);
			loc[3] = new Location(1, 4);
		} else if (rnd == 2) {
			col = Color.CYAN;
			for (int i = 0; i < 2; i ++) {
				loc[i] = new Location (0, i + 4);
			}
			loc[2] = new Location(1, 4);
			loc[3] = new Location(1, 5);
		} else if (rnd == 3) {
			col = Color.YELLOW;
			loc[1] = new Location(0, 3);
			loc[0] = new Location(0, 4);
			loc[2] = new Location(0, 5);
			loc[3] = new Location(1, 3);
		} else if (rnd == 4) {
			col = Color.MAGENTA;
			loc[1] = new Location(0, 3);
			loc[0] = new Location(0, 4);
			loc[2] = new Location(0, 5);
			loc[3] = new Location(1, 5);
		} else if (rnd == 5) {
			col = Color.BLUE;
			loc[0] = new Location(0, 4);
			loc[1] = new Location(0, 5);
			loc[2] = new Location(1, 3);
			loc[3] = new Location(1, 4);
		} else if (rnd == 6) {
			col = Color.GREEN;
			loc[1] = new Location(0, 3);
			loc[0] = new Location(0, 4);
			loc[2] = new Location(1, 4);
			loc[3] = new Location(1, 5);
		}
		
		/*for(int i = 0; i < blocks.length; i++) {
			blocks[i].setColor(col);
		}*/
		ArrayList<Location> loca = grid.getOccupiedLocations();
		for (Location checkMe : loca) {
			if (checkMe.equals(loc[0]) || checkMe.equals(loc[1]) || checkMe.equals(loc[2]) || checkMe.equals(loc[3])) {
				System.out.println("GAME OVER");
				System.exit(0);
			}
		}
		
		addToLocations(grid, loc);
	}


	// Postcondition: Attempts to move this tetrad deltaRow rows down and
	//						deltaCol columns to the right, if those positions are
	//						valid and empty.
	//						Returns true if successful and false otherwise.
	public boolean translate(int deltaRow, int deltaCol)
	{
		BoundedGrid<Block> theGrid = blocks[0].getGrid();
		Location[] oldLocations = removeBlocks();
		Location[] newLocations = new Location[blocks.length];
		for (int i = 0; i < 4; i++) {
			Location old = oldLocations[i];
			newLocations[i] = new Location(old.getRow() + deltaRow, 
					old.getCol() + deltaCol);
		}
		if (areEmpty(theGrid, newLocations)) {
			addToLocations(theGrid, newLocations);
			return true;
		} else {
			addToLocations(theGrid, oldLocations);
		}
	return false;
		//throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	// Postcondition: Attempts to rotate this tetrad clockwise by 90 degrees
	//                about its center, if the necessary positions are empty.
	//                Returns true if successful and false otherwise.
	public boolean rotate()
	{
		BoundedGrid<Block> grid = blocks[0].getGrid();
		Location oldLoc[] = removeBlocks();
		Location newLoc[] = new Location[oldLoc.length];
		for(int i = 0; i < 4; i++) {
			newLoc[i] = new Location(
					oldLoc[0].getRow() - oldLoc[0].getCol() + oldLoc[i].getCol(), 
					oldLoc[0].getRow() + oldLoc[0].getCol() - oldLoc[i].getRow());
		}
		if(areEmpty(grid, newLoc)) {
			addToLocations(grid, newLoc);
			return true;
		} else { 
			addToLocations(grid, oldLoc);
		}
		return false;
		//throw new RuntimeException("INSERT MISSING CODE HERE");
	}


	// Precondition:  The elements of blocks are not in any grid;
	//                locs.length = 4.
	// Postcondition: The elements of blocks have been put in the grid
	//                and their locations match the elements of locs.
	private void addToLocations(BoundedGrid<Block> grid, Location[] locs)
	{
		for(int i = 0; i < 4; i ++) {
			blocks[i] = new Block();
			blocks[i].setColor(color);
			blocks[i].putSelfInGrid(grid, locs[i]);
		}
		//throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	// Precondition:  The elements of blocks are in the grid.
	// Postcondition: The elements of blocks have been removed from the grid
	//                and their old locations returned.
	private Location[] removeBlocks()
	{
		Location[] locs = new Location[blocks.length];
		for (int i = 0; i < blocks.length; i++)
		{
			locs[i] = blocks[i].getLocation();
			blocks[i].removeSelfFromGrid();
		}
		return locs;
		//throw new RuntimeException("INSERT MISSING CODE HERE");
	}

	// Postcondition: Returns true if each of the elements of locs is valid
	//                and empty in grid; false otherwise.
	private boolean areEmpty(BoundedGrid<Block> grid, Location[] locs)
	{
		/*int count = 0;
		for (int i = 0; i < locs.length; i ++) {
			if (grid.isValid(locs[i])) {
				if (grid.get(locs[i]) != null) {
					count++;
				}
			}
		}
		return !(count == 4);*/
		boolean empty = true;
		ArrayList<Location> occuLocs = grid.getOccupiedLocations();
		for (int i = 0; i < 4; i++) {
			for (Location qloc : occuLocs) {
				if (qloc.equals(locs[i])) empty = false;
			}
			if (!grid.isValid(locs[i])) empty = false;
		}
		return empty;
		//throw new RuntimeException("INSERT MISSING CODE HERE");
	}
}
